/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Empleado;
import Vista.PanelAlta;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Controlador {

// Método para validar nombre
    public static String validacionNombre(String nombre) {
      
            if (nombre.isEmpty()) {
                return "El nombre no puede estar vacio";
            }
            return null;
    }
    
    //Validar fecha de nacimiento
    public static String validacionFecha(int dia, int mes, int anio) {
        
        GregorianCalendar fechaActual = new GregorianCalendar();

        if (anio < 1900 || anio > 2015) {
            return "El año debe estar entre 1900 y 2015";
        }

        if (mes < 1 || mes > 12) {
            return "El mes debe estar entre 1 y 12";
        }

        if (dia < 1 || dia > 31) {
            return "El día debe estar entre 1 y 31";
        }

        // Crear la fecha con el mes ajustado
        GregorianCalendar fechaNacimiento = new GregorianCalendar(anio, mes - 1, dia);

        if (fechaNacimiento.after(fechaActual)) {
            return "La fecha de nacimiento no puede ser en el futuro.";
        }

        return null;

      
     }
    
    // Validar salarios
    
    public static String validacionSueldos(double salario, double max) {
      
            if (salario < 0 || max < 0) {
                return "Los sueldos no pueden ser menor de 0" ;
            }
        
            if (salario > max) {
                return"El sueldo debe ser menos que el sueldo maximo" ;
            }
            return null;
     }
    
           
}


    
    
    


    
   


