/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;
import Controlador.Controlador;
import Modelo.Empleado;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Maria
 */
public class PanelAlta extends JPanel {
    
    // Componentes gráficos para la alta de empleados
    
    //etiquetas
    private JLabel etNombre, etFechaNac, etSueldo, etSueldoMax;
    //campos
    private JTextField textNombre, textFechaNac, textSueldo, textSueldoMax;
    //botones
    private JButton botonAceptar, botonCancelar;

    //error
    private JLabel error;
    
    public PanelAlta() {
        
        // Configuración del layout del panel
        setLayout(new GridLayout(6, 2));

        // Inicialización de etiquetas
        etNombre = new JLabel("Nombre:");
        etFechaNac = new JLabel("Fecha de Nacimiento(dd/mm/yyyy:");
        etSueldo = new JLabel("Sueldo:");
        etSueldoMax = new JLabel("Sueldo Máximo:");
        
        // Inicialización de los campos
        textNombre = new JTextField();
        textFechaNac = new JTextField();
        textSueldo = new JTextField();
        textSueldoMax = new JTextField();
        
        // Inicialización de los botones
        botonAceptar = new JButton("Aceptar");
        botonCancelar = new JButton("Cancelar");
        
        // Inicialización del campo de error 
        error = new JLabel(""); // Inicialmente vacío 
        error.setForeground(java.awt.Color.RED); // Color rojo para los errores
        
        // Añadimos los componentes al panel
        add(etNombre); 
        add(textNombre);
        add(etFechaNac); 
        add(textFechaNac);
        add(etSueldo); 
        add(textSueldo);
        add(etSueldoMax); 
        add(textSueldoMax);
        add(botonAceptar); 
        add(botonCancelar);
        add(error);

        // Acción para el botón Aceptar (creación del nuevo empleado)
        botonAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    // Obtener los valores de los campos de texto
                    String nombre = textNombre.getText();
                    String[] fechaArray = textFechaNac.getText().split("/"); //convertimos la fecha en un array
                    double sueldo = Double.parseDouble(textSueldo.getText());
                    double sueldoMax = Double.parseDouble(textSueldoMax.getText());
                    // Validamos el nombre
                    String errMensaje=Controlador.validacionNombre(nombre);
                    if (errMensaje!=null) {
                        mostrarError(errMensaje); 
                        return; 
                    }
                    
                    //Convertimos el array de fecha en numeros enteros 
                    int dia = Integer.parseInt(fechaArray[0]);
                    int mes = Integer.parseInt(fechaArray[1]) ; 
                    int anio = Integer.parseInt(fechaArray[2]);
                    
                    //Validamos fecha
                    errMensaje=Controlador.validacionFecha(dia, mes, anio);
                     if (errMensaje!=null) {
                        mostrarError(errMensaje); 
                        return; 
                    }
                     
                    //Validamos salarios
                    errMensaje=Controlador.validacionSueldos(sueldo, sueldoMax);
                    if (errMensaje!=null) {
                        mostrarError(errMensaje); 
                        return; 
                    }
                     //Convetimos cada numero entero correspondiente a calendario Gregoriano
                    GregorianCalendar fechaNac = new GregorianCalendar(anio, mes-1, dia); // Meses empiezan desde 0
                    
                    // Creamos un nuevo empleado
                    Empleado nuevoEmpleado=new Empleado(nombre, fechaNac, sueldo, sueldoMax);
                    
                    // Limpiamos los campos después de la inserción
                    textNombre.setText("");
                    textFechaNac.setText("");
                    textSueldo.setText("");
                    textSueldoMax.setText("");
               } catch (NumberFormatException ex) {
                    mostrarError("Error en el formato de los números. Asegúrese de que son válidos.");
                    return;
               } catch(Exception ex){
                   mostrarError(ex.getMessage());
               }

            }  
            
            private void mostrarError(String mensajeError){
                error.setText(mensajeError);
                error.setVisible(true);
            }
            
        });
        
        

        // Acción para el botón Cancelar (limpia los campos)
        botonCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textNombre.setText("");
                textFechaNac.setText("");
                textSueldo.setText("");
                textSueldoMax.setText("");
            }
        });
        
        
    }

   
}


