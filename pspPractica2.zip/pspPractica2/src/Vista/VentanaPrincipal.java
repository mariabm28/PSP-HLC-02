/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Modelo.Empleado;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.*;

/**
 *
 * @author Maria
 */
public class VentanaPrincipal extends JFrame  {
    
    private static JPanel panelPrinci;
    
    private static PanelVer panelV;
    private static PanelAlta panelA;
    private static PanelInfo panelI;
    

    public VentanaPrincipal(){
        
        //Introducimos empleados
        Empleado emp1 = new Empleado("Juan Lopez", new GregorianCalendar(1990, 5, 15), 3000.25, 5000.0);
        Empleado emp2 = new Empleado("Ana Perez", new GregorianCalendar(1985, 2, 25), 3500.48, 5500.0);
        Empleado emp3 = new Empleado("Luis Garcia", new GregorianCalendar(2000, 7, 10), 4000.54, 6000.0);
        Empleado emp4 = new Empleado("Veronica Rios", new GregorianCalendar(1995, 6, 28), 3060.86, 4000.0);
              
        // Inicializamos los paneles
        panelV = new PanelVer();  // Panel para visualizar empleados
        panelA = new PanelAlta();  // Panel para añadir nuevos empleados
        panelI = new PanelInfo();  // Panel para mostrar información del autor

        // Configuramos las propiedades básicas de la ventana
        setTitle("Gestión de Empleados");   // Título de la ventana
        setSize(600, 400);                 // Tamaño fijo de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Cierra la app al pulsar el botón de cerrar
        setResizable(false);               // Deshabilitamos el redimensionamiento de la ventana

        // Creamos el panel principal donde mostraremos los otros paneles
        panelPrinci = new JPanel();
        panelPrinci.setLayout(new CardLayout()); // Usamos un CardLayout para cambiar entre paneles
        panelPrinci.add(panelV, "Ver");
        panelPrinci.add(panelA, "Alta");
        panelPrinci.add(panelI, "Informacion");

        // Añadimos el panel principal al JFrame
        add(panelPrinci, BorderLayout.CENTER);

        // Añadimos la barra de menú
        setJMenuBar(crearMenuBar());

        // Mostramos el primer panel (por defecto el panel "Ver")
        mostrarPanel("Ver");

        
     }
    // Método para crear la barra de menú con las opciones "Ver", "Alta" y "Acerca de"
    private JMenuBar crearMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // Creamos un menú
        JMenu menu = new JMenu("Menú");

        // Creamos los elementos del menú
        JMenuItem itemVer = new JMenuItem("Ver Empleados");
        JMenuItem itemAlta = new JMenuItem("Alta Empleado");
        JMenuItem itemInformacion = new JMenuItem("Acerca de");

        // Añadimos los elementos al menú
        menu.add(itemVer);
        menu.add(itemAlta);
        menu.add(itemInformacion);

        // Añadimos el menú a la barra de menú
        menuBar.add(menu);

        // Agregamos las acciones a los elementos del menú
        itemVer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanel("Ver");
            }
        });

        itemAlta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanel("Alta");
            }
        });

        itemInformacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanel("Informacion");
            }
        });

        return menuBar;
    }

    // Método para mostrar el panel correspondiente
    private void mostrarPanel(String nombrePanel) {
        CardLayout layout = (CardLayout) panelPrinci.getLayout();
        layout.show(panelPrinci, nombrePanel); // Cambiamos el panel que se muestra
    }

    // Método principal para ejecutar la aplicación
    public static void main(String[] args) {
        // Creamos una instancia de la ventana principal
        VentanaPrincipal ventana = new VentanaPrincipal();

        // Hacemos visible la ventana
        ventana.setVisible(true);     
        
        
    }
}

    
    

