/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Modelo.Empleado;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Maria
 */
public class PanelVer extends JPanel {
    
    // Componentes gráficos para mostrar la información de los empleados
    //Etiquetas
    private JLabel etiqNumEmpleado, etiqNombre, etiqFechaNac, etiqSueldo, etiqSueldoMax;
    //Campos
    private JTextField textNumEmpleado, textNombre, textFechaNac, textSueldo, textSueldoMax;
    //Botones
    private JButton botonPrimero, botonAnterior, botonSiguiente, botonUltimo;
    
    
    public PanelVer(){
        // Configuración del layout y la estructura del panel 
        setLayout(new GridLayout(7, 2)); // 7 filas y 2 columnas
        
        // Inicialización de los etiquetas
        etiqNumEmpleado = new JLabel("Número de Empleado:");
        etiqNombre = new JLabel("Nombre:");
        etiqFechaNac = new JLabel("Fecha de Nacimiento:");
        etiqSueldo = new JLabel("Sueldo:");
        etiqSueldoMax = new JLabel("Sueldo Máximo:");
        
        //Inicializamos los campos
        textNumEmpleado = new JTextField();
        textNombre = new JTextField();
        textFechaNac = new JTextField();
        textSueldo = new JTextField();
        textSueldoMax = new JTextField();
        
        // Inicializamos los botones
        botonPrimero = new JButton("Primero");
        botonAnterior = new JButton("Anterior");
        botonSiguiente = new JButton("Siguiente");
        botonUltimo = new JButton("Último");

        // Desactivamos la edición de los campos de texto para que solo sean de lectura
        textNumEmpleado.setEditable(false);
        textNombre.setEditable(false);
        textFechaNac.setEditable(false);
        textSueldo.setEditable(false);
        textSueldoMax.setEditable(false);
        
        // Añadimos los componentes al panel
        add(etiqNumEmpleado); 
        add(textNumEmpleado);
        add(etiqNombre); 
        add(textNombre);
        add(etiqFechaNac); 
        add(textFechaNac);
        add(etiqSueldo); 
        add(textSueldo);
        add(etiqSueldoMax);
        add(textSueldoMax);
        add(botonPrimero); 
        add(botonUltimo);
        add(botonAnterior); 
        add(botonSiguiente);
        
        // Añadimos acciones a los botones para navegar entre los empleados
        botonPrimero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarEmpleado(Empleado.getPrimero());
            }
        });

        botonUltimo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarEmpleado(Empleado.getUltimo());
            }
        });

        botonAnterior.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarEmpleado(Empleado.retroceder());
            }
        });

        botonSiguiente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarEmpleado(Empleado.avanzar());
            }
        });
        
        //Cargamos el primer empleado al inciciar el panel
        mostrarEmpleado(Empleado.getPrimero());
    }

    // Método para mostrar los datos de un empleado en los campos de texto
    private void mostrarEmpleado(Empleado empleado) {
        if (empleado != null) {
            textNumEmpleado.setText(String.valueOf(empleado.getNumEmpleado()));
            textNombre.setText(empleado.getNombre());
                        
            // Usamos SimpleDateFormat para formatear la fecha
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            textFechaNac.setText(sdf.format(empleado.getFechaNac().getTime()));// Conversión de fecha
            
            textSueldo.setText(String.valueOf(empleado.getSueldo()));
            textSueldoMax.setText(String.valueOf(empleado.getSueldoMax()));
            
            // Verificamos si es el primero o el último para desactivar/activar los botones 
            actualizarBotones();    
        }        
        
    }
    
    // Método para actualizar el estado de los botones según la posición actual
    private void actualizarBotones() {
        // Desactivamos botones "Primero" y "Anterior" si estamos en el primer empleado
        if (Empleado.esPrimero()) {
            botonPrimero.setEnabled(false);
            botonAnterior.setEnabled(false);
        } else {
            botonPrimero.setEnabled(true);
            botonAnterior.setEnabled(true);
        }

        // Desactivamos botones "Último" y "Siguiente" si estamos en el último empleado
        if (Empleado.esUltimo()) {
            botonUltimo.setEnabled(false);
            botonSiguiente.setEnabled(false);
        } else {
            botonUltimo.setEnabled(true);
            botonSiguiente.setEnabled(true);
        }
    }




    
    }
    

