/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;



/**
 *
 * @author Maria
 */
public class PanelInfo extends JPanel{
    
    public PanelInfo() {
        // Configuración del layout
        setLayout(new BorderLayout());

        // Creamos una etiqueta con información del autor
        JLabel labelInfo = new JLabel("<html><center>Aplicación de Gestión de Empleados de la asignatura PSP del curso 2ºDAM <br> Autor: María Bernabé Montiel</center></html>");
        
          // Centramos el texto horizontalmente y verticalmente
        labelInfo.setHorizontalAlignment(SwingConstants.CENTER); // Centrado horizontal
        labelInfo.setVerticalAlignment(SwingConstants.CENTER); // Centrado vertical
        
        // Cambiamos el color del texto (puedes usar un color predefinido o crear uno personalizado)
        labelInfo.setForeground(Color.BLUE); // Cambia el color del texto a azul

        // Añadimos la etiqueta al panel
        add(labelInfo, BorderLayout.CENTER);
    }
}


