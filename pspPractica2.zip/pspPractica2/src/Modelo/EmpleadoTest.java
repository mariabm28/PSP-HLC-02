/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import Modelo.Empleado;

import java.util.*;
import java.util.GregorianCalendar;

public class EmpleadoTest {
    public static void main(String[] args) {
        
        // Crear algunos empleados para probar
        Empleado emp1 = new Empleado("Juan", new GregorianCalendar(1990, 5, 15), 3000.0, 5000.0);
        Empleado emp2 = new Empleado("Ana", new GregorianCalendar(1985, 2, 25), 3500.0, 5500.0);
        Empleado emp3 = new Empleado("Luis", new GregorianCalendar(2000, 7, 10), 4000.0, 6000.0);

        // Imprimir la lista de empleados
        System.out.println("Lista de empleados:");
        Empleado actual = Empleado.getPrimero();
        while (actual != null) {
            System.out.println(actual);
            actual = actual.siguiente;
        }

        // Probar si es el primero o el último
        System.out.println("\nVerificando si es el primer o último empleado:");
        System.out.println("El empleado actual es: " + Empleado.actual);
        System.out.println("¿Es el primero? " + Empleado.esPrimero());
        System.out.println("¿Es el último? " + Empleado.esUltimo());

        // Probar avanzar
        System.out.println("\nAvanzando en la lista:");
        Empleado.avanzar();
        System.out.println("Empleado actual después de avanzar: " + Empleado.actual);

        // Probar retroceder
        System.out.println("\nRetrocediendo en la lista:");
        Empleado.retroceder();
        System.out.println("Empleado actual después de retroceder: " + Empleado.actual);

        // Probar obtener el último empleado
        System.out.println("\nObteniendo el último empleado:");
        Empleado ultimo = Empleado.getUltimo();
        System.out.println("Último empleado: " + ultimo);
    }
}
