/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class Empleado {
    
    private int numEmpleado;
    private String nombre;
    private GregorianCalendar fechaNac;
    private double sueldo;
    private double sueldoMax;
    
    public Empleado siguiente;
    public static Empleado inicio=null;
    public static Empleado actual=null;
    public static Empleado aux=null;
    
    private static int contadorEmp=1;

    public Empleado(String nombre, GregorianCalendar fechaNac, double sueldo, double sueldoMax) {
        
        this.numEmpleado=contadorEmp++;
        this.nombre = nombre;
        this.fechaNac = fechaNac;
        this.sueldo = sueldo;
        this.sueldoMax = sueldoMax;
        
        // Enlazar a la lista de empleados
        if (inicio == null) {
            inicio = this; // Primer empleado en la lista
        } else {
            // Si no es el primer empleado, recorremos la lista para encontrar el último
            aux = inicio;
            while (aux.siguiente != null) {
                aux = aux.siguiente; // Avanzamos al siguiente empleado
            }
        // Enlazamos el último empleado con el nuevo
        aux.siguiente = this;
        
        }


        
    }

   
    public int getNumEmpleado() {
        return numEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public GregorianCalendar getFechaNac() {
        return fechaNac;
    }

    public double getSueldo() {
        return sueldo;
    }

    public double getSueldoMax() {
        return sueldoMax;
    }

    public Empleado getSiguiente() {
        return siguiente;
    }

    public static Empleado getInicio() {
        return inicio;
    }
    
    public static double actualGetSueldoMax() {
        
        return actual.getSueldoMax();
    }   
        
    public static double actualGetSueldo() {
        
        return actual.getSueldo();
    }    
    
     public static GregorianCalendar  actualGetFechaNac() {
        
        return actual.getFechaNac();
    }

    public static String actualGetNombre() {
        
        return actual.getNombre();
    }
    
    public static int actualGetNumEmpleado() {
        
        return actual.getNumEmpleado();
    }    
    

    public static int getContadorEmp() {
        return contadorEmp;
    }
    
    
// Métodos para navegar por la lista de empleados
    public static Empleado getPrimero() {
        actual = inicio;
        return actual;
    }
    
    public static Empleado getUltimo() {
        aux = inicio;
        if (aux != null) {
            while (aux.siguiente != null) {
                aux = aux.siguiente; // Avanzar hasta el último empleado
            }
            actual = aux; // El último empleado se convierte en el "actual"
        }
        return actual;
    }

    
    public static Empleado avanzar() {
        if (actual != null && actual.siguiente != null) {
            actual = actual.siguiente;
        }
        return actual;
    }
    
    public static Empleado retroceder() {
        if (actual != null && actual != inicio) {
            aux = inicio;
            while (aux.siguiente != actual) { // Recorremos hasta encontrar el anterior al actual
                aux = aux.siguiente;
            }
            actual = aux; // Hacemos que el anterior sea el actual
        }
        return actual;
    }
    
    // Método para saber si el empleado actual es el primero
    public static boolean esPrimero() {
        return actual == inicio;
    }

    // Método para saber si el empleado actual es el último
    public static boolean esUltimo() {
        return actual != null && actual.siguiente == null;
    }

        public String getFormattedFechaNac() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(fechaNac.getTime()); // Convierte GregorianCalendar a Date y luego a String
    }

    
    @Override
    public String toString() {
        return "Empleado{" + "numEmpleado=" + numEmpleado + 
                ", nombre=" + nombre + ", "
                + "fecha nacimiento=" + getFormattedFechaNac() +
                ", sueldo=" + sueldo +
                ", sueldo maximo=" + sueldoMax + '}';
    }

    


}
